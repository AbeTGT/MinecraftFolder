Thanks for downloading the 1.0 Beta Release for MinecraftFolder.

You'll need to unzip this or drag it to your destination.

2022 AbeTGT.